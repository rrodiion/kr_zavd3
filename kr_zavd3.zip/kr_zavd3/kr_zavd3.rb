class Book
  # Конструктор класу, приймає назву, автора та рік видання
  def initialize(title, author, year)
    @title = title
    @author = author
    @year = year
  end

  # Метод для отримання назви книги
  def title
    @title
  end

  # Метод для встановлення назви книги
  def title=(new_title)
    @title = new_title
  end

  # Метод для отримання автора книги
  def author
    @author
  end

  # Метод для встановлення автора книги
  def author=(new_author)
    @author = new_author
  end

  # Метод для отримання року видання книги
  def year
    @year
  end

  # Метод для встановлення року видання книги
  def year=(new_year)
    @year = new_year
  end
end

# Створення екземпляру класу "Книга"
my_book = Book.new("The Call Of The Wild", "Jack London", 2020)

# Отримання та виведення властивостей
puts "Назва книги: #{my_book.title}"
puts "Автор: #{my_book.author}"
puts "Рік видання: #{my_book.year}"

# Зміна назви книги та року видання
my_book.title = "White Fang"
my_book.year = 2022

# Виведення змінених властивостей
puts "Нова назва книги: #{my_book.title}"
puts "Новий рік видання: #{my_book.year}"
